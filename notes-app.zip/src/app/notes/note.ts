export interface Note {
    id: number;
    title: string;
    details?: string|undefined;
}